var ddData = [
    {
        text: "EN",
        value: 1,
        selected: false,
        imageSrc: "./images/us.svg"
    },
    {
        text: "CZ",
        value: 2,
        selected: false,
        imageSrc: "./images/cz.svg"
    }
];

document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', function() {
        const accordionItem = this.parentElement;
        const accordionContent = accordionItem.querySelector('.accordion-content');

        if (!accordionItem.classList.contains('active')) {
            document.querySelectorAll('.accordion-item.active').forEach(item => {
                item.classList.remove('active');
                item.querySelector('.accordion-content').style.maxHeight = null;
            });

            accordionItem.classList.add('active');
            accordionContent.style.maxHeight = accordionContent.scrollHeight + "px";
        } else {
            accordionItem.classList.remove('active');
            accordionContent.style.maxHeight = null;
        }
    });
});


jQuery(document).ready(function() {
    jQuery(".catalog_items_block .favorite").click(function() {
        jQuery(this).toggleClass("active");
    });
});

jQuery(document).ready(function() {
    jQuery(".filter_item .title_block").click(function() {
        jQuery(this).toggleClass("active");
        jQuery('.filter_item .content_block').toggleClass("active");
    });
});


jQuery(document).ready(function() {
    $('.detail_image_for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.detail_image_nav'
    });
    $('.detail_image_nav').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        infinite: true,
        asNavFor: '.detail_image_for',
        dots: false,
        centerMode: true,
        vertical: true,
        verticalSwiping: true,
        focusOnSelect: true
    });
});

jQuery(document).ready(function() {
    $('.reviews_general').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});

jQuery(document).ready(function() {
    $('.reviews_general_double').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
});

document.querySelectorAll('.tab-button').forEach(button => {
    button.addEventListener('click', function() {
        const tabNumber = this.getAttribute('data-tab');

        // Удаляем активный класс у всех кнопок и контента
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

        // Добавляем активный класс к текущей кнопке и соответствующему контенту
        this.classList.add('active');
        document.getElementById(`tab-${tabNumber}`).classList.add('active');
    });
});

document.querySelectorAll('.tab-button_second').forEach(button => {
    button.addEventListener('click', function() {
        const tabNumber = this.getAttribute('data-tab');

        // Удаляем активный класс у всех кнопок и контента
        document.querySelectorAll('.tab-button_second').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content_second').forEach(content => content.classList.remove('active'));

        // Добавляем активный класс к текущей кнопке и соответствующему контенту
        this.classList.add('active');
        document.getElementById(`tab-${tabNumber}`).classList.add('active');
    });
});


document.querySelector('.increment').addEventListener('click', function() {
    const quantityInput = document.querySelector('.quantity');
    let quantity = parseInt(quantityInput.value);
    quantityInput.value = quantity + 1;
});

document.querySelector('.decrement').addEventListener('click', function() {
    const quantityInput = document.querySelector('.quantity');
    let quantity = parseInt(quantityInput.value);
    if (quantity > 1) {
        quantityInput.value = quantity - 1;
    }
});



$('#myDropdown').ddslick({
    data:ddData,
    width:300,
    imagePosition:"left",
    onSelected: function(selectedData){
        //callback function: do something with selectedData;
    }
});

var ddData1 = [
    {
        text: "EN",
        value: 1,
        selected: false,
        imageSrc: "../images/us.svg"
    },
    {
        text: "CZ",
        value: 2,
        selected: false,
        imageSrc: "../images/cz.svg"
    }
];


$('#myDropdown1').ddslick({
    data:ddData1,
    width:300,
    imagePosition:"left",
    onSelected: function(selectedData){
        //callback function: do something with selectedData;
    }
});





const openPopupBtn = document.getElementById('open-popup-btn');
const popupOverlay = document.getElementById('popup-overlay');
const closeBtn = document.getElementById('close-btn');

// Функция для открытия попапа
openPopupBtn.addEventListener('click', function() {
    popupOverlay.style.display = 'flex';
    document.body.classList.add('popup-active');
});

// Функция для закрытия попапа
function closePopup() {
    popupOverlay.style.display = 'none';
    document.body.classList.remove('popup-active');
}

// Закрытие по крестику
closeBtn.addEventListener('click', closePopup);

// Закрытие по клику вне попапа
popupOverlay.addEventListener('click', function(e) {
    if (e.target === popupOverlay) {
        closePopup();
    }
});










































